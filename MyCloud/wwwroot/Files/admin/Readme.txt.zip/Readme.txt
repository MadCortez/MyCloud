Mouse Recorder Pro is an input recording application (mouse & keyboard input) ,
with this application you can create script's of recordings you have made ( moving your mouse,
clicking on a button, pressing keys) , now all of these annoying repetitive tasks
will be done easily!

Features:

- easy to understand interface.
- small sized.
- you can play any script how much time you want.
- set a script to be played in a specific time.
- save and load your scripts with no limits!
- edit your scripts by using the event editing system.

Notes:
Please uninstall any other version of Mouse Recorder Pro.

By Shynet �

Nemex 2008 , visit us at : http://planet.nana10.co.il/nemex2008 .

Contact us at : shynet@gmail.com .